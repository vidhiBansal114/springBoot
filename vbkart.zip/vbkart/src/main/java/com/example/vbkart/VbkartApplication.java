package com.example.vbkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VbkartApplication {

	public static void main(String[] args) {
		SpringApplication.run(VbkartApplication.class, args);
	}

}
